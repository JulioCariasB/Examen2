package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Labo extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img1,img2,img3,img4,img5,img6,img7,img8,img9;
	int altura, anchura;
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		img1 = new Texture("namek.jpg");
		img2 = new Texture("Goku.png");
		img3 = new Texture("Gohan.png");
		img4 = new Texture("Vegeta.png");
		img5 = new Texture("Golden.png");
		img6 = new Texture("Cell.png");
		img7 = new Texture("Buu.png");
		img8 = new Texture("explo.png");
		img9 = new Texture("gt.png");
		altura = Gdx.graphics.getWidth();
		anchura = Gdx.graphics.getHeight();

		Sound sound = Gdx.audio.newSound(Gdx.files.internal("kame.mp3"));
		sound.play();
		Music music= Gdx.audio.newMusic(Gdx.files.internal("DragonBall.mp3"));
		music.play();
	}

	@Override
	public void render() {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		batch.draw(img1, 0, 0, altura, anchura);
		batch.draw(img8, 0, 300);
			batch.draw(img8, 405, 300);
			batch.draw(img2, 125, 100);
			batch.draw(img3, 300, 300);
			batch.draw(img4, 125, 500);
			batch.draw(img5, 940, 100);
			batch.draw(img6, 740, 300);
			batch.draw(img7, 940, 500);
			batch.draw(img9, 480, 0);

		batch.end();
	}
}
